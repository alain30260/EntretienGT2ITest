<?php

require("dbcall.php");

//On recupere le catalogue
$xml = simplexml_load_file("catalogue.XML");

$tableau=array(25);

// selectionne les elements de fLigne
foreach($xml->children() as $fLigne) {
    $a=0;
    foreach($fLigne->children() as $child) {
        // data contient les valeurs de chaque attributs de fLigne
        $tableau[$a]=$child;
        $a++;
    }

//insere les valeurs dans la base de donnees
$rep2 = $bdd->prepare('INSERT INTO Produits_Details(
        PRODUIT_POCLEUNIK,
        PRODUIT_REF,
        REFCIALE_ARCLEUNIK,
        REFCIALE_REFART,
        REFCIALE_REFCAT,
        POTRAD_DESI,
        REFCIALE_CTVA,
        FICTECH_MEMOCAT,
        FICTECH_MEMONET,
        PRODUIT_MARQUE,
        PRODUIT_CLEP01,
        PRODUIT_CLEP02,
        PRODUIT_CLEP03,
        PRODUIT_CLEP04,
        PRODUIT_CLEP06,
        PRODUIT_CLEP07,
        PRODUIT_GCOLORIS,
        PRODUIT_GTAILLE,
        PRODUIT_CLEP12,
        REFCIALE_FICHEINA,
        REFCIALE_MODTE,
        PRODUIT_MODTE,
        ARTICLE_POIDS,
        ARTICLE_HNORMEL,
        ARTICLE_CATEG
)
VALUES(
    :PRODUIT_POCLEUNIK,
    :PRODUIT_REF,
    :REFCIALE_ARCLEUNIK,
    :REFCIALE_REFART,
    :REFCIALE_REFCAT,
    :POTRAD_DESI,
    :REFCIALE_CTVA,
    :FICTECH_MEMOCAT,
    :FICTECH_MEMONET,
    :PRODUIT_MARQUE,
    :PRODUIT_CLEP01,
    :PRODUIT_CLEP02,
    :PRODUIT_CLEP03,
    :PRODUIT_CLEP04,
    :PRODUIT_CLEP06,
    :PRODUIT_CLEP07,
    :PRODUIT_GCOLORIS,
    :PRODUIT_GTAILLE,
    :PRODUIT_CLEP12,
    :REFCIALE_FICHEINA,
    :REFCIALE_MODTE,
    :PRODUIT_MODTE,
    :ARTICLE_POIDS,
    :ARTICLE_HNORMEL,
    :ARTICLE_CATEG)'
);
$rep2->execute(array(
    'PRODUIT_POCLEUNIK' => $tableau[0],
    'PRODUIT_REF' => $tableau[1],
    'REFCIALE_ARCLEUNIK' => $tableau[2],
    'REFCIALE_REFART' => $tableau[3],
    'REFCIALE_REFCAT' => $tableau[4],
    'POTRAD_DESI' => $tableau[5],
    'REFCIALE_CTVA' => $tableau[6],
    'FICTECH_MEMOCAT' => $tableau[7],
    'FICTECH_MEMONET' => $tableau[8],
    'PRODUIT_MARQUE' => $tableau[9],
    'PRODUIT_CLEP01' => $tableau[10],
    'PRODUIT_CLEP02' => $tableau[11],
    'PRODUIT_CLEP03' => $tableau[12],
    'PRODUIT_CLEP04' => $tableau[13],
    'PRODUIT_CLEP06' => $tableau[14],
    'PRODUIT_CLEP07' => $tableau[15],
    'PRODUIT_GCOLORIS' => $tableau[16],
    'PRODUIT_GTAILLE' => $tableau[17],
    'PRODUIT_CLEP12' => $tableau[18],
    'REFCIALE_FICHEINA' => $tableau[19],
    'REFCIALE_MODTE' => $tableau[20],
    'PRODUIT_MODTE' => $tableau[21],
    'ARTICLE_POIDS' => $tableau[22],
    'ARTICLE_HNORMEL' => $tableau[23],
    'ARTICLE_CATEG' => $tableau[24]
));
}
echo 'le chargement de article.xml est terminé';
