<?php
/*
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future.
*
*  @author   Alain
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Stockmail extends Module
{
    private $html = '';

    public function __construct()
    {
        $this->name = 'stockmail';
        $this->tab = 'emailing';
        $this->version = '1.0.0';
        $this->author = 'Alain';
        $this->need_instance = 0;
        $this->ps_version_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('stockmail');
        $this->description = $this->l('Send mail when stocks change.');

        $this->confirmationUninstall = $this->l('Are you sure you want to uninstall?');
    }

    /**
     * installation function of module with registration on the hook
     * @return [bool] [true or false for installation]
     */
    public function install()
    {
        if (!parent::install() || !$this->registerHook('displayOrderConfirmation')) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * fonction de desinstallation
     * @return [bool] [true or false for uninstallation]
     */

    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * function to get the email value and separate it with comas
     * @return [string] [mail]
     */
    public function getContent()
    {
        if (Tools::isSubmit('submit')) {
            Configuration::updateValue('emails', Tool::getValue('csv'));
        }
        $this->displayForm();
        return $this->_html;
    }

    /**
     * function to insert the confirmation mail adress
     * @return [html] [page to add mailin back office]
     */
    private function displayForm()
    {
        $this->_html .= '
        <form action="'.$_SERVER['REQUEST_URL'].'" method="post">
        <label>'.$this->l('Email adresses to send notification email').'</label>
        <div class="margin-form">
            <input type="text" name="csv" />
        </div><br />
        <input type="submit" name="submit" value="'.$this->l('Save').'"
        class="button" />
        </form>';
    }

    /**
     * send mail with quantity ordered from the hook with the template from view folder
     * @param  [array] $params [content values of the order]
     * @return [send the mail]
     */
    public function hookdisplayOrderConfirmation($params)
    {
        $mymail = Configuration::get('PS_SHOP_EMAIL');

        Mail::Send(
            (int)(Configuration::get('PS_LANG_DEFAULT')), // defaut language id
            'views/templates/stockmail', // email template file to be use
            $this->displayName.' Les stock de ' . $params['product_id'] . 'ont changés', // email subject
            array(
                '{email}' => Configuration::get('PS_SHOP_EMAIL'), // sender email address
                '{message}' =>  'Un Client a commandé ' . $params['cart_quantity'] . ' de ' . $params['product_id']// email message
            ),
            $mymail, // receiver email address
            null,
            null,
            null
        );
    }
}
