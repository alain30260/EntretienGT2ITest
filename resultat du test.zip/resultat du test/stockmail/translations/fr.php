<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{stockmail}prestashop>stockmail_799301afac11d440832411e5b56ee8de'] = 'stockmail';
$_MODULE['<{stockmail}prestashop>stockmail_d4122ee2c044fe26cc0b146751ce4d8b'] = 'Envoi un courriel quand les stocks changent.';
$_MODULE['<{stockmail}prestashop>stockmail_876f23178c29dc2552c0b48bf23cd9bd'] = 'Etes vous sur de vouloir desinstaller ?';
$_MODULE['<{stockmail}prestashop>stockmail_1f0ccb9903b959b25c1bdcf34f326fdb'] = 'Adresse courriel pour envoyer les notifications.';
$_MODULE['<{stockmail}prestashop>stockmail_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
